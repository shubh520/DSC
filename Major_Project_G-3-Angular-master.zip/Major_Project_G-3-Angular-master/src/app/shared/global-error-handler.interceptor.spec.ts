import { GlobalErrorHandler } from "./global-error-handler.interceptor";

 

describe('GlobalErrorHandler', () => {
  it('should create an instance', () => {
    expect(new GlobalErrorHandler()).toBeTruthy();
  });
});