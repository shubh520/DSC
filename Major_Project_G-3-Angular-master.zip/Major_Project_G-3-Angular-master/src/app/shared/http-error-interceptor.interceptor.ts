import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpErrorResponse

} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable()
export class HttpErrorInterceptorInterceptor implements HttpInterceptor {

  constructor() {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request)
        .pipe(
            retry(1),
            catchError((error: HttpErrorResponse) => {
                let errorMessage = '';
                if (error.error instanceof ErrorEvent) {
                    errorMessage = `client-Error: ${error.error}`;
                } else {
                    errorMessage = `server-Error:  ${error.error}  status code:  ${error.status}`;
                    ///you can modify message based on status code
                    switch (error.status) {
                        case 404:
                            errorMessage = 'this is 404 status code' + error.error
                            break;
                        case 401:
                            errorMessage = 'this is 401 status code'+ error.error
                            break;
                        case 500:
                                console.log()
                                errorMessage = 'this is 500 status code'+ error.error
                             break;
                        case 300:
                                console.log()
                                errorMessage = 'this is 300 status code'+ error.error
                             break;

                    }
                }
                // console.log(' error using interceptor ' + errorMessage);
                return throwError(errorMessage);
            })
        )
}
}
