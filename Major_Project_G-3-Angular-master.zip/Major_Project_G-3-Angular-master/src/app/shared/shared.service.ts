import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { Observable } from 'rxjs';
import { Otp } from '../models/otp';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
 

  
  constructor(private http: HttpClient) { }
  url = "http://localhost:9090/";

  getUserByUserName(username:string) {
    return this.http.get(this.url + "user/username/" + username);
  }
 
  VerfyOpt(otpdetail :Otp) {
    return this.http.post(this.url+"user/verifyOtp",otpdetail,{responseType: "text"});
  }
  
  passwordReset(forgotPassword: any,param1:String) {
    return this.http.put(this.url+"user/resetpassword?token="+param1,forgotPassword)
  }
  generateOtp(email: string) {
    return this.http.post(this.url+"user/forgetpassword",email,{responseType: "text"});
  }
 

 registerUserFromRemote(user:User):Observable<any>{
   console.log("WE ARE in SERVCE");
   
    return this.http.post(this.url+"user/registeruser",user,{responseType: "text"});
    }
   
  changePassword(data:any,userid :any):Observable<any> {
      console.log(data);
      console.log(userid);
      let temp = data;
      console.log(temp);
      delete temp.confirmpass;
      console.log(temp);
      return this.http.put(this.url + "user/update-password/"+userid,temp,{responseType: "text"});
    }
}
