import { TestBed } from '@angular/core/testing';

import { AuthinterceptorService } from './auth-interceptor.service';

describe('AuthInterceptorService', () => {
  let service: AuthinterceptorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthinterceptorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
