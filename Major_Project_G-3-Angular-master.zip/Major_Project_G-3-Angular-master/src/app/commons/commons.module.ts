import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { ErrorComponent } from './error/error.component';
import { RegistrationDirective } from './registration.directive';
import { AppModule } from '../app.module';
import { FormsModule } from '@angular/forms';
import { RegistrationComponent } from './registration/registration.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';



@NgModule({
  declarations: [LoginComponent, LogoutComponent, ErrorComponent, RegistrationDirective, RegistrationComponent, ChangePasswordComponent, ForgetPasswordComponent, ResetpasswordComponent],
  imports: [
    CommonModule,FormsModule
  ],
  exports:[LoginComponent,LogoutComponent,ErrorComponent,RegistrationDirective,ChangePasswordComponent, ForgetPasswordComponent,ResetpasswordComponent]
})
export class CommonsModule { }
