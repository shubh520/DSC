import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { SharedService } from 'src/app/shared/shared.service';
import { Otp } from 'src/app/models/otp';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
flag: Number 
alert: boolean=false;
  user = new User();
  otpdetail = new Otp();
  msg='';
  
  
  constructor(private service: SharedService ,private _router: Router) { }

  ngOnInit(): void {
    this.flag = 0;
  }

registerUser(){
  console.log(this.user);
  let resultstate= this.service.registerUserFromRemote(this.user)
    console.log(resultstate);
    
    resultstate.subscribe((data:any)=>{
      console.log("Inside Subscribe");
      console.log(":)"+data.status);
      this.flag=1; 

      console.log(data);
      
      // if(data==="We have sent a  opt to your email. Please check ")
      // {
      //   this.flag=1; 
      //   console.log(this.flag);

        
      // }
    });
   
  
//   this.service.registerUserFromRemote(this.user).subscribe(
// data=>{

//   console.log("response received");
//   this.flag = 1;
// //  this._router.navigate(['/login']);
// // this.alert=true;




}
validateOtp(){
  this.otpdetail.email = this.user.userEmail;
  console.log(this.otpdetail);
  let resultstate= this.service.VerfyOpt(this.otpdetail)
  console.log(resultstate);
  
  resultstate.subscribe((data:any)=>{
    console.log(":)"+data.status);
    console.log(data);
    this.alert=true;

    
    if(data==="otp verified ")
    {
      this.alert=true;

      
    }
  });


}
closeAlert(){
  this.alert=false
}
}
