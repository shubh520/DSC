

import { Component, OnInit, Input } from '@angular/core';
import { User } from 'src/app/models/user';
import { Router } from '@angular/router';
import {FormsModule} from '@angular/forms';
import{ NgForm} from '@angular/forms';
import { AuthenticationService } from 'src/app/shared/authentication.service';

import { SharedService } from 'src/app/shared/shared.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  constructor(private as : AuthenticationService, 
    private router: Router,
    private uservice:  SharedService,
    ) { }

  ngOnInit() {
  }
  @Input() errorMessage = ""
  username:string 
  password:string 
  onLogin(){
    this.as.authenticate(this.username, this.password).subscribe(
      (data:any) => {
        console.log("IN LOGIN"+ JSON.stringify(data));
        this.uservice.getUserByUserName(this.username).subscribe((res: any) => {
          console.log("Checking LOgin"+JSON.stringify(res));
          sessionStorage.setItem("userid", res.userId);
          console.log(data);

        });
        if (data.roles[0] === "ROLE_customer") {
          this.router.navigate(["userhome"]);
        }
        if (data.roles[0] === "ROLE_admin") {
          this.router.navigate(["admin"]);
        }
        if (data.roles[0] === "ROLE_manager") {
          this.router.navigate(["manager"]);
        }
      },
      error =>{
        //stay on same page
        this.errorMessage = 'LOgin failure'
      }
    )
  }
  gotoregistration(){
  
    this.router.navigate(['/registration'])
  }

 

 
}
  
