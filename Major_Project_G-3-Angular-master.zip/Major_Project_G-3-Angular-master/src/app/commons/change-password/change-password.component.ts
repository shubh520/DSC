import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  userId: any;
  role: String;
  newpassword:String;
  confirmpassword:String;
  oldpassword:String;
  constructor(private service: SharedService, private router: Router) {}

  ngOnInit(): void {
  }
  changePassword(changepassForm: { value: any; }) {
    if(this.newpassword===this.confirmpassword)
    {
    this.userId = sessionStorage.getItem("userid") || "";

    this.service
      .changePassword(changepassForm.value, this.userId)
      .subscribe((data: any) => {
        if (data) {
          alert("password changed successfully");
          this.role = sessionStorage.getItem("userrole")|| "";
          if (this.role === "ROLE_customer") {
            this.router.navigate(["user"]);
          }
          if (this.role === "ROLE_admin") {
            this.router.navigate(["admin"]);
          }
          if (this.role === "ROLE_manager") {
            this.router.navigate(["manager"]);
          }
        } else {
          alert("old password is incorrect");
        }
      });
  }
  else{
    alert("new password and confirm password does not match");
  }

}
}


