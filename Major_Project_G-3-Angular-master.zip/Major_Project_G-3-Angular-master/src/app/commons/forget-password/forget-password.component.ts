import { Component, OnInit, OnChanges } from '@angular/core';
import { SharedService } from 'src/app/shared/shared.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit,OnChanges {
  param1: string;
  param2: string;
  constructor( private service:  SharedService,private router:Router,private route: ActivatedRoute) { 
}
  flag:Number = 0; 
  email:string = "";
  password:string = ""
  ngOnChanges(): void {
    console.log(this.email);
    
  }
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.param1 = params['param1'];
      console.log(this.param1)
     
       });
  }
  genertelink(formData: { value: any; })
  {
    console.log(formData);
    
    alert("In generate otp");
    let resultstate=this.service.generateOtp(this.email);
    console.log(resultstate);
    
    resultstate.subscribe((data:any)=>{
      console.log(":)"+data.status);
      console.log(data);
      
      if(data==="Otp sent to email id")
      {
        this.flag=1; 

        
      }
    });
  }
  // Reset Password
 
}