import { RegistrationDirective } from './registration.directive';

describe('RegistrationDirective', () => {
  it('should create an instance', () => {
    const directive = new RegistrationDirective();
    expect(directive).toBeTruthy();
  });
});
