import { Directive } from '@angular/core';

@Directive({
  selector: '[appRegistration]'
})
export class RegistrationDirective {

  constructor() { }

}
