import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared/shared.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {
  password:String;
  confirmpassword:String;
  param:String;
  constructor( private service:  SharedService,private router:Router,private route: ActivatedRoute) { 
  }

  ngOnInit(): void {this.route.queryParams.subscribe(params => {
    this.param = params['token'];
    console.log(this.param)
   
     });
}
 
  resetPassword(resetPassword: any)
  { 
    if(this.password===this.confirmpassword)
    {
      let resultstate=this.service.passwordReset(this.password,this.param);
      resultstate.subscribe((data:any)=>{
        console.log(":)"+data.data);
        if(data==="user password updated succesfully")
        {
          this.router.navigate(['/login'])
   
        }
        
      }); 
      
      }
      
  }
}
