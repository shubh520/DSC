export class Sport 
{
    sportId:number;
    sportName:string;
    
}
