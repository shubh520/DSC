export class Otp {
    email: String;
    otp: String
}
