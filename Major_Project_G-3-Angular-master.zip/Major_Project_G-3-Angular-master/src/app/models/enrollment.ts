import { Time } from '@angular/common'

export class Enrollment {

        enrollmentId:number
        userName: string
        firstName: string
        lastName: string
        userCity: string
        batchType: string
        batchPrice: number
        batchStartTime: Time
        batchEndTime: Time
        batchStartDate: Date
        batchEndDate: Date
        availableSize: number
        batchSize: number
        sportName: string
        enrollmentStatus:string 
        enrollmentDate:Date 
}
