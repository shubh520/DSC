import { Time } from '@angular/common'

export class Invoice {
  enrollmentId:number
	 userId:number
	 userName:string
	firstName:string
	lastName:string
	 userCity:string
	
	 batchId:number
	 batchType:string
	batchPrice:number
	 batchStartTime:Time
	 batchEndTime:Time
	 batchStartDate :Date
	 batchEndDate :Date
	
	 sportId:number
	sportName:string
	enrollmentDate:Date 
    enrollmentStatus:string 
    
}
