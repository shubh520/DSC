import { Time } from '@angular/common';

export class Batch
{
    batchId: number
    batchType: string
    batchPrice: string
	batchStartTime: Time
	batchEndTime: Time
	batchStartDate: Date
    batchEndDate: Date
    commentId :number
    commentDescription:string
   userName:string
   availableSize:number
   batchSize:number
   offerPrice:string
   sportName:string
   sportId:number;
   userId:number;
}
