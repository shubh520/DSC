export class Likes {
    likeId : number;
}
