export class Comments
 {
    commentDescription:string
    firstName:string
}
