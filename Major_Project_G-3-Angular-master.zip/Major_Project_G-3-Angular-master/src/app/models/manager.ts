export class Manager 
{
    userId:number
    userName:string
    firstName:string
    lastName:string
    userCity:string
    userEmail:string
    userPassword:string
    accountStatus:string = "pending"
    role:string = "manager"

}
