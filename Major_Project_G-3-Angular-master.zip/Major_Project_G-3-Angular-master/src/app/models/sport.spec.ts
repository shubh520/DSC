import { Sport } from './sport';

describe('Sport', () => {
  it('should create an instance', () => {
    expect(new Sport()).toBeTruthy();
  });
});
