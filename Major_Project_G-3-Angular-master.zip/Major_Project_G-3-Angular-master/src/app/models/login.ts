export class Login {
    username:string;
    password:string
   

    constructor(
        userame:string,
        password:string
       
    ){}
}
