export class Offer {
}
