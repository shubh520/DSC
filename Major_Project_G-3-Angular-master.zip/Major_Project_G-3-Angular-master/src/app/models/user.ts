export class User {
    userid:number;
    userName:String;
    firstName:String;
    lastName:String;
    userCity:String;
    userEmail:String;
    userPassword:String;
    accountStatus:String="pending";
    role:String="customer";
    constructor(){}
    }
