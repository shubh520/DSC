import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListSportComponent } from './admin/list-sport/list-sport.component';
import { CreateSportComponent } from './admin/create-sport/create-sport.component';
import { CreateManagerComponent } from './admin/create-manager/create-manager.component';
import { ListManagerComponent } from './admin/list-manager/list-manager.component';
import { UpdateManagerComponent } from './admin/update-manager/update-manager.component';
import { UpdateSportComponent } from './admin/update-sport/update-sport.component';
import { PendingEnrollmentComponent } from './manager/pending-enrollment/pending-enrollment.component';
import { ManagerHomeComponent } from './manager/manager-home/manager-home.component';
import { ApprovedEnrollmentComponent } from './manager/approved-enrollment/approved-enrollment.component';
import { RejectedEnrollmentComponent } from './manager/rejected-enrollment/rejected-enrollment.component';
import { ListSportUComponent } from './user/list-sport-u/list-sport-u.component';
import { ListofbatchesComponent } from './user/listofbatches/listofbatches.component';
import { BatchdetailsComponent } from './user/batchdetails/batchdetails.component';
import { GenerateReceiptComponent } from './user/generate-receipt/generate-receipt.component';
import { MyMembershipComponent } from './user/my-membership/my-membership.component';
import { LoginComponent } from './commons/login/login.component';
import { AdminHomeComponent } from './admin/admin-home/admin-home.component';
import { HomepageComponent } from './homepage/homepage.component';
import { AuthGuard } from './shared/auth.guard';
import { UserHomeComponent } from './user/user-home/user-home.component';
import { RegistrationComponent } from './commons/registration/registration.component';
import { AdminSportReportComponent } from './reports/admin-sport-report/admin-sport-report.component';
import { ChangePasswordComponent } from './commons/change-password/change-password.component';
import { ForgetPasswordComponent } from './commons/forget-password/forget-password.component';
import { ResetpasswordComponent } from './commons/resetpassword/resetpassword.component';
import { UnlockUserComponent } from './admin/unlock-user/unlock-user.component';
import { ThankYouComponent } from './user/thank-you/thank-you.component';
import { LogoutComponent } from './commons/logout/logout.component';
import { UpdateUserProfileComponent } from './user/update-user-profile/update-user-profile.component';
import { ApprovedMembershipComponent } from './user/approved-membership/approved-membership.component';
import { RenewMembershipComponent } from './user/renew-membership/renew-membership.component';
import { ListBatchComponent } from './manager/list-batch/list-batch.component';
import { UpdateBatchComponent } from './manager/update-batch/update-batch.component';
import { CreateBatchComponent } from './manager/create-batch/create-batch.component';



const routes: Routes = [
  {path: '', component: HomepageComponent },
  // { path: 'userhome', component: UserHomeComponent },
  { path: 'listsport', component: ListSportComponent },
  { path: 'listsportu', component: ListSportUComponent},
  { path: 'listofbatches/:id', component: ListofbatchesComponent},
  { path: 'batchdetails/:id', component: BatchdetailsComponent},
  { path: 'createsport', component: CreateSportComponent },
  { path: 'listmanager', component: ListManagerComponent },
  { path: 'createmanager', component: CreateManagerComponent },
  { path: 'updatemanager/:id', component: UpdateManagerComponent },
  { path: 'updatesport/:id', component: UpdateSportComponent },
  { path:'adminhome', component:AdminHomeComponent },
  { path: 'sport/export', component: AdminSportReportComponent },
  {
    path: 'login',
    component: LoginComponent
  },

  { path: 'pendingenrollment', component: PendingEnrollmentComponent},
  { path: 'managerhome', component: ManagerHomeComponent},
  { path: 'approvedenrollment', component: ApprovedEnrollmentComponent},
  { path: 'rejectedenrollment', component: RejectedEnrollmentComponent},

  { path: 'invoice/:id', component:GenerateReceiptComponent},
  { path: 'myMembership/:id', component:MyMembershipComponent},
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'thankyou/:id', component: ThankYouComponent },
  { path: 'updateuserprofile', component:UpdateUserProfileComponent },
  { path: 'approvedMembership', component: ApprovedMembershipComponent },
  { path: 'renewMembership/:id', component: RenewMembershipComponent },
  

  { path: 'listbatchbymanager', component: ListBatchComponent },
  { path: 'createbatch', component: CreateBatchComponent },
  { path: 'updatebatch/:id', component: UpdateBatchComponent },



  {
    path: 'admin',
    component: AdminHomeComponent,
    canActivate: [AuthGuard],
    data: {role: "ROLE_admin"}
  },

  {
    path: 'manager',
    component: ManagerHomeComponent,
    canActivate: [AuthGuard],
    data: {role: "ROLE_manager"}
  },
  {
    path: 'unlock-request',
    component:  UnlockUserComponent,
    canActivate: [AuthGuard],
    data: {role: "ROLE_admin"}
  },

  {path:'registration',
  component:RegistrationComponent},
  {
    path: 'userhome',
    component: UserHomeComponent,
    canActivate: [AuthGuard],
    data: {role: "ROLE_customer"}
  },
 
  {
    path:'change-password',
  component: ChangePasswordComponent
  },

  {
    path:'forgetpassword',
  component: ForgetPasswordComponent 
  },

  {
    path:'resetpasssword',
  component:  ResetpasswordComponent 
  },
  
  {
    path:'resetpasssword?:token',
  component:  ResetpasswordComponent 
  }
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


