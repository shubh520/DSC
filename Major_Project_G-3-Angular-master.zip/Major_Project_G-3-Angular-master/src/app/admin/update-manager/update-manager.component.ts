import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Manager } from 'src/app/models/manager';

@Component({
  selector: 'app-update-manager',
  templateUrl: './update-manager.component.html',
  styleUrls: ['./update-manager.component.css']
})
export class UpdateManagerComponent implements OnInit {

  userId: number;
  manager: Manager;
  // route: any;

  constructor(private adminService: AdminServiceService,
    private router: Router, private route: ActivatedRoute) { }



  ngOnInit() {
    this.manager = new Manager();

    this.userId =  this.route.snapshot.params.id;
    
    this.adminService.getManager(this.userId)
      .subscribe(data => {
        console.log(data)
        this.manager = data;
      }, error => console.log(error));
  }

  updateManager() {
    this.adminService.updateManager(this.userId, this.manager)
      .subscribe(data => {
        console.log(data);
        this.manager = new Manager();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateManager();    
  }

  gotoList() {
    this.router.navigate(['/listmanager']);
  }
}
