import { Component, OnInit, Inject } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import { Router } from '@angular/router';
import { Manager } from 'src/app/models/manager';
import { Observable } from 'rxjs';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-unlock-user',
  templateUrl: './unlock-user.component.html',
  styleUrls: ['./unlock-user.component.css']
})
export class UnlockUserComponent implements OnInit {
 
 managers:Observable<Manager[]>;
 alert: boolean=false;
 firstname: String;
  constructor(
    private service: AdminServiceService,@Inject(DOCUMENT) private document: Document
  ) {}

  ngOnInit() {
   this.reloadData();
   console.log(this.managers);
  }
  reloadData(){
    this.managers= this.service.getunlockerequest();

    console.log(this.managers);
  }


  Unlock(userid: Number) {
    this.service.getunlockuser(userid).subscribe((res: any) => {
      if (res != null) {
        this.alert = true;
        this.firstname= res.firstName;
        this.document.location.reload();
      }
    });
  }
  closeAlert(){
    this.alert=false
  }
}