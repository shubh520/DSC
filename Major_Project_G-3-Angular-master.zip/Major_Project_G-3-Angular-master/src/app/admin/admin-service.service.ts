import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {
  private Url = 'http://localhost:9090/admin'
  getunlockuser(userId: Number) {
    let tempurl = "unlock-account"
    return this.http.get(`${this.Url}/${tempurl}/${userId}`, { responseType: 'text' });
  }
  
  getunlockerequest(): Observable<any> {
   let tempurl = "unlock-request";
   console.log("In UNLOck");
    return this.http.get(`${this.Url}/${tempurl}`);
  }

  private baseUrl = 'http://localhost:9090/admin/sport';

  constructor(private http: HttpClient) { }

  getSport(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createSport(sport: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`,sport);
  }

  updateSport(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteSport(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getSportList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
  exportSportPdf(): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/export/pdf`, { responseType: 'blob' });
  }

  //manager logic

  private mbaseUrl = 'http://localhost:9090/admin/manager';


  getManager(id: number): Observable<any> {
    return this.http.get(`${this.mbaseUrl}/${id}`);
  }

  createManager(manager: Object): Observable<Object> {
    return this.http.post(`${this.mbaseUrl}`,manager);
  }

  updateManager(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.mbaseUrl}/${id}`, value);
  }

  deleteManager(id: number): Observable<any> {
    return this.http.delete(`${this.mbaseUrl}/${id}`, { responseType: 'text' });
  }

  getManagerList(): Observable<any> {
    return this.http.get(`${this.mbaseUrl}`);
  }

  getEverySport(){
    return this.http.get(`http://localhost:9090/admin/everysport`);
  }

}
