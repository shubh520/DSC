import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service'
import {Sport} from 'src/app/models/sport'
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-sport',
  templateUrl: './update-sport.component.html',
  styleUrls: ['./update-sport.component.css']
})
export class UpdateSportComponent implements OnInit {

  sportId: number;
  sport: Sport;
 

  constructor(private adminService: AdminServiceService,
    private router: Router, private route: ActivatedRoute) { }



  ngOnInit() {
    this.sport = new Sport();

    this.sportId =  this.route.snapshot.params.id;
    
    this.adminService.getSport(this.sportId)
      .subscribe(data => {
        console.log(data)
        this.sport = data;
      }, error => console.log(error));
  }

  updateSport() {
    this.router.navigate(['/listsport']);
    this.adminService.updateSport(this.sportId, this.sport)
      .subscribe(data => {
        console.log(data);
        this.sport = new Sport();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateSport();    
  }

  gotoList() {
    this.router.navigate(['/listsport']);
  }

}