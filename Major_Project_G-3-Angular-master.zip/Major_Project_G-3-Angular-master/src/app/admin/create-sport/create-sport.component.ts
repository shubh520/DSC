import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service'
import { Observable } from "rxjs";
import {Sport} from 'src/app/models/sport'
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-sport',
  templateUrl: './create-sport.component.html',
  styleUrls: ['./create-sport.component.css']
})
export class CreateSportComponent implements OnInit {
  sport: Sport = new Sport();
  submitted = false;

  constructor(private adminService: AdminServiceService,
    private router: Router) { }


  ngOnInit() {
  }

  addSport(): void {
    this.submitted = false;
    this.sport = new Sport();
  }

  save() {
    this.router.navigate(['/listsport']);
    this.adminService
    .createSport(this.sport).subscribe(data => {
      console.log(data)
      //this.sport = new Sport;
      // this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/listsport']);
  }
}
