import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service'
import { Observable } from "rxjs";
import {Sport} from 'src/app/models/sport'
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-sport',
  templateUrl: './list-sport.component.html',
  styleUrls: ['./list-sport.component.css']
})
export class ListSportComponent implements OnInit {
  sports: Observable<Sport[]>;

  constructor(private adminService: AdminServiceService,
    private router: Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.sports = this.adminService.getSportList();
  //  this.adminService.getSportList().subscribe(sport=>this.sports = sport)
    console.log(this.sports);
  }

  deleteSport(sportId: number) {
    this.adminService.deleteSport(sportId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
  createSport() {
    this.router.navigate(['/createsport']);
  }
  updateSport(sportId:number) {
    // this.router.navigate(['/updatemanager/'+{userId}]);
    this.router.navigate(['/updatesport', sportId]);
  }
  

  // sportDetails(id: number){
  //   this.router.navigate(['details', id]);
  // }

}
