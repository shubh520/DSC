import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import { Router } from '@angular/router';
import { Manager } from 'src/app/models/manager';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-create-manager',
  templateUrl: './create-manager.component.html',
  styleUrls: ['./create-manager.component.css']
})
export class CreateManagerComponent implements OnInit {
  manager: Manager = new Manager();
  submitted = false;
  sports: Observable<any>;

  constructor(private adminService: AdminServiceService,
    private router: Router) { }


  ngOnInit() {
    this.sports = this.adminService.getEverySport();
  }

  addManager(): void {
    this.submitted = false;
    this.manager = new Manager();
  }

  save() {
    
    this.router.navigate(['/listmanager']);
    this.adminService
    .createManager(this.manager).subscribe(data => {
      console.log(data)
      //this.sport = new Sport;
      // this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/listmanager']);
  }

}
