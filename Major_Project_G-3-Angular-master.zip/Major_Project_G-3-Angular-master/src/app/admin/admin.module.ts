import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { CreateSportComponent } from './create-sport/create-sport.component';
import { UpdateSportComponent } from './update-sport/update-sport.component';
import { ListSportComponent } from './list-sport/list-sport.component';
import { CreateManagerComponent } from './create-manager/create-manager.component';
import { ListManagerComponent } from './list-manager/list-manager.component';
import { UpdateManagerComponent } from './update-manager/update-manager.component';
import { CommonsModule } from '../commons/commons.module';
import { UnlockUserComponent } from './unlock-user/unlock-user.component';




@NgModule({
  declarations: [AdminHomeComponent, CreateSportComponent, UpdateSportComponent, ListSportComponent, CreateManagerComponent, ListManagerComponent, UpdateManagerComponent, UnlockUserComponent],
  imports: [
    CommonModule,
     CommonsModule 
  ]
})

export class AdminModule { }
