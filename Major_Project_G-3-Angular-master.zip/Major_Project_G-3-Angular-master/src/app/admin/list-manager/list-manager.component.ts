import { Component, OnInit } from '@angular/core';
import { Manager } from 'src/app/models/manager';
import { Observable } from 'rxjs';
import { AdminServiceService } from '../admin-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-manager',
  templateUrl: './list-manager.component.html',
  styleUrls: ['./list-manager.component.css']
})
export class ListManagerComponent implements OnInit {

  managers: Observable<Manager[]>;

  constructor(private adminService: AdminServiceService,
    private router: Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.managers = this.adminService.getManagerList();
  //  this.adminService.getSportList().subscribe(sport=>this.sports = sport)
    console.log(this.managers);
  }

  deleteManager(userId: number) {
    this.adminService.deleteManager(userId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
  createManager() {
    this.router.navigate(['/createmanager']);
  }

  updateManager(userId:number) {
    // this.router.navigate(['/updatemanager/'+{userId}]);
    this.router.navigate(['updatemanager', userId]);
  }
  


  // sportDetails(id: number){
  //   this.router.navigate(['details', id]);
  // }


}
