import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Sport } from 'src/app/models/sport';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {

  sports: Observable<Sport[]>;

  constructor(private adminService: AdminServiceService,
    private router: Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.sports = this.adminService.getSportList();
  //  this.adminService.getSportList().subscribe(sport=>this.sports = sport)
    console.log(this.sports);
  }
getSportList(){
  this.router.navigate(['/listsport']);
}

}
