import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovedEnrollmentComponent } from './approved-enrollment.component';

describe('ApprovedEnrollmentComponent', () => {
  let component: ApprovedEnrollmentComponent;
  let fixture: ComponentFixture<ApprovedEnrollmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprovedEnrollmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovedEnrollmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
