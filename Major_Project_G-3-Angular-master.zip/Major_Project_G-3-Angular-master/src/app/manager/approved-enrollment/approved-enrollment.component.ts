import { Component, OnInit } from '@angular/core';
import { ManagerServiceService } from '../manager-service.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Enrollment } from 'src/app/models/enrollment';

@Component({
  selector: 'app-approved-enrollment',
  templateUrl: './approved-enrollment.component.html',
  styleUrls: ['./approved-enrollment.component.css']
})
export class ApprovedEnrollmentComponent implements OnInit {

  aenrollments: Observable<Enrollment[]>;

  constructor(private managerService: ManagerServiceService, private router: Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.aenrollments = this.managerService.getApprovedEnrollmentList();
  //  this.adminService.getSportList().subscribe(sport=>this.sports = sport)
    console.log(this.aenrollments);
  }

}
