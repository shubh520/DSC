import { Component, OnInit } from '@angular/core';
import { Batch } from 'src/app/models/batch';
import { ManagerServiceService } from '../manager-service.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Sport } from 'src/app/models/sport';

@Component({
  selector: 'app-create-batch',
  templateUrl: './create-batch.component.html',
  styleUrls: ['./create-batch.component.css']
})
export class CreateBatchComponent implements OnInit {
 batch: Batch = new Batch();
 sport:Observable<any>;
 mysportName:string;
 // batch: Observable<Batch[]>;
  submitted = false;
  constructor(private managerService: ManagerServiceService,
    private router: Router) { }

  ngOnInit() {
    this.sport =this.managerService.getSportByUserId()
  }
  addBatch(): void {
    this.submitted = false;
    this.batch.userId = 4;

  }

  save() {

    this.router.navigate(['/listbatchbymanager']);
    this.batch.sportName = this.mysportName;
    this.batch.userId = 4
    console.log(this.batch  )
    this.managerService
    .createBatch(this.batch).subscribe(data => {
      console.log(data)
      //this.sport = new Sport;
      // this.gotoList();
    },
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }

  gotoList() {
    this.router.navigate(['/listbatchbymanager']);
  }

  selectChange(event: any){
    this.mysportName = event.target.value;

  }
}
