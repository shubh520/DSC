import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Enrollment } from 'src/app/models/enrollment';
import { ManagerServiceService } from '../manager-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pending-enrollment',
  templateUrl: './pending-enrollment.component.html',
  styleUrls: ['./pending-enrollment.component.css']
})
export class PendingEnrollmentComponent implements OnInit {

  enrollments: Observable<Enrollment[]>;

  constructor(private managerService: ManagerServiceService, private router: Router) { }

  ngOnInit(): void {
    this.reloadData();

  }

  ngOnChanges(){
    this.reloadData();

  }

  reloadData(){
    this.enrollments = this.managerService.getPendingEnrollmentList();
  //  this.adminService.getSportList().subscribe(sport=>this.sports = sport)
    console.log(this.enrollments);
  }

  approveEnrollment(userId: number){
   // window.location.reload();
   console.log("my user id", userId);
    this.managerService.approveEnrollment(userId)
      .subscribe(
        userId => {
          console.log("my dataaaa:",userId);
          this.router.navigate(['/managerhome']);
        },
        error => console.log(error));
  }

  rejectEnrollment(userId: number){
     this.managerService.rejectEnrollment(userId)
      .subscribe(
      data => {
      this.reloadData();
      console.log(data);
  },
    error => console.log(error));
}

}
