import { Component, OnInit } from '@angular/core';
import { ManagerServiceService } from '../manager-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Sport } from 'src/app/models/sport';
import { Batch } from 'src/app/models/batch';
import { FormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, NgForm } from '@angular/forms';

@Component({
  selector: 'app-update-batch',
  templateUrl: './update-batch.component.html',
  styleUrls: ['./update-batch.component.css']
})
export class UpdateBatchComponent implements OnInit {
  batchId: number;
  sport: Sport;
  batch: Batch;
  //route: any;
  updateBatchForm :any

  constructor(private managerService: ManagerServiceService,
    private router: Router,private route:ActivatedRoute) {
      this.batch=new Batch();
     }
 ngOnInit() {
    this.batch = new Batch();
    this.batchId =  this.route.snapshot.params.id;
    this.managerService.getBatchById(this.batchId)
      .subscribe(data => {
        console.log(data)
        this.batch = data;
      }, error => console.log(error));
  }

 updateBatch() {
  this.router.navigate(['/listbatchbymanager']);

    this.managerService.updateBatch(this.batchId, this.batch)
      .subscribe(data => {
        console.log(data);
        this.batch = new Batch();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateBatch();
  }

  gotoList() {
    this.router.navigate(['/listbatchbymanager']);
  }
 
}


