import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Manager } from 'src/app/models/manager';
import { ManagerServiceService } from '../manager-service.service';
import { Batch } from 'src/app/models/batch';

@Component({
  selector: 'app-list-batch',
  templateUrl: './list-batch.component.html',
  styleUrls: ['./list-batch.component.css']
})
export class ListBatchComponent implements OnInit {
  batches: Observable<Batch[]>;

  constructor(private managerService: ManagerServiceService,
    private router: Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.batches = this.managerService.getBatchList();

  //  this.adminService.getSportList().subscribe(sport=>this.sports = sport)
    console.log(this.batches);
  }

  deleteBatch(deleteBatch: number) {
    this.managerService.deleteBatch(deleteBatch)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
  createBatch() {
    this.router.navigate(['/createbatch']);
  }

  updateBatch(batchId:number) {
    // this.router.navigate(['/updatebatch/'+{batchId}]);
    this.router.navigate(['/updatebatch', batchId]);
  }



  // sportDetails(id: number){
  //   this.router.navigate(['details', id]);
  // }



}
