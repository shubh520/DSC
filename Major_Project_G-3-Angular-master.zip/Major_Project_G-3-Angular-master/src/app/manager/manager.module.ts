import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManagerHomeComponent } from './manager-home/manager-home.component';
import { PendingEnrollmentComponent } from './pending-enrollment/pending-enrollment.component';
import { ApprovedEnrollmentComponent } from './approved-enrollment/approved-enrollment.component';
import { RejectedEnrollmentComponent } from './rejected-enrollment/rejected-enrollment.component';
import { ListBatchComponent } from './list-batch/list-batch.component';
import { UpdateBatchComponent } from './update-batch/update-batch.component';
import { CreateBatchComponent } from './create-batch/create-batch.component';



@NgModule({
  declarations: [ManagerHomeComponent, PendingEnrollmentComponent, ApprovedEnrollmentComponent, RejectedEnrollmentComponent, ListBatchComponent, UpdateBatchComponent, CreateBatchComponent],
  imports: [
    CommonModule
  ]
})
export class ManagerModule { }
