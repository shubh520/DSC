import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Batch } from '../models/batch';

@Injectable({
  providedIn: 'root'
})
export class ManagerServiceService {

  private baseUrl = 'http://localhost:9090/manager';

  constructor(private http: HttpClient) { }


  // public userId:any = sessionStorage.getItem("userid") || '';
  public userId:any=4;
  batchId:any;
  getEnrollmentList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/enrollment`);
  }

  getPendingEnrollmentList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/enrollment/bystatus/pending/3`);
  }

  approveEnrollment(enrollmentId:number): Observable<any>{
    console.log("my ID",enrollmentId);
    return this.http.put(`${this.baseUrl}/enrollment/updatestatus/${enrollmentId}/approved`, {});
  }

  rejectEnrollment(enrollmentId:number): Observable<any>{
    return this.http.put(`${this.baseUrl}/enrollment/updatestatus/${enrollmentId}/rejected`, {});
  }

  getApprovedEnrollmentList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/enrollment/bystatus/approved/3`);
  }

  getRejectedEnrollmentList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/enrollment/bystatus/rejected/3`);
  }


  //Batch List

  getBatchList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/batch/4`);
  }
  deleteBatch(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/batch/${id}`, { responseType: 'text' });
  }

  updateBatch(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/batch/${id}`, value);
  }

  createBatch(batch: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/batch`,batch);
  }
  getSportByUserId(){
    return this.http.get(`${this.baseUrl}/batch/sportByUserId/${this.userId}`);

  }

  getBatchById(batchId:any):Observable<any>{
    return this.http.get(`${this.baseUrl}/batch/batchId/${batchId}`);

  }
    
}
