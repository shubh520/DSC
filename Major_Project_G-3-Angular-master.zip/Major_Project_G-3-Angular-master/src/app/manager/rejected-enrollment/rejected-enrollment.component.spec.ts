import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectedEnrollmentComponent } from './rejected-enrollment.component';

describe('RejectedEnrollmentComponent', () => {
  let component: RejectedEnrollmentComponent;
  let fixture: ComponentFixture<RejectedEnrollmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RejectedEnrollmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RejectedEnrollmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
