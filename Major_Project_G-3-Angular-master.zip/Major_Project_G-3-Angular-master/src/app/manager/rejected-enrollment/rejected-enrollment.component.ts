import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Enrollment } from 'src/app/models/enrollment';
import { ManagerServiceService } from '../manager-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rejected-enrollment',
  templateUrl: './rejected-enrollment.component.html',
  styleUrls: ['./rejected-enrollment.component.css']
})
export class RejectedEnrollmentComponent implements OnInit {

  enrollments: Observable<Enrollment[]>;

  constructor(private managerService: ManagerServiceService, private router: Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.enrollments = this.managerService.getRejectedEnrollmentList();
  //  this.adminService.getSportList().subscribe(sport=>this.sports = sport)
    console.log(this.enrollments);
  }


}
