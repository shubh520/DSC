import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListofbatchesComponent } from './listofbatches.component';

describe('ListofbatchesComponent', () => {
  let component: ListofbatchesComponent;
  let fixture: ComponentFixture<ListofbatchesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListofbatchesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListofbatchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
