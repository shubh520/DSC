import { Component, OnInit } from '@angular/core';
import { Batch } from 'src/app/models/batch';
import { ActivatedRoute, Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-listofbatches',
  templateUrl: './listofbatches.component.html',
  styleUrls: ['./listofbatches.component.css']
})
export class ListofbatchesComponent implements OnInit {

  id: number;

  batches: any;

  constructor(private route: ActivatedRoute,private router: Router,
    private userService: UserServiceService) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.id = this.route.snapshot.params['id'];
    //this.batches = this.userService.getBatches(this.id)
    this.userService.getBatches(this.id).subscribe((data: any)=>
    {
      this.batches=data;
    })
  
   
   
  }
  getBatchDetails(id: number)
  {
    this.router.navigate(['batchdetails', id]);
  }
  
}
