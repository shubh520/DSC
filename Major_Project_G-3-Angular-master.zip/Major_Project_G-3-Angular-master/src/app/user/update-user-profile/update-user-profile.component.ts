import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-update-user-profile',
  templateUrl: './update-user-profile.component.html',
  styleUrls: ['./update-user-profile.component.css']
})
export class UpdateUserProfileComponent implements OnInit {

  constructor(private userService: UserServiceService,
    private router: Router) { }


    user: any
    userId:any
    setUser : User;
  ngOnInit()
   {
    this.setUser = new User();
    this.userId = sessionStorage.getItem('userid') || '';
    this.userService.getuserProfile(this.userId).subscribe((data: any)=>
    {
      this.user=data;
    });
   }

   updateUser()
   {
    this.userId = sessionStorage.getItem('userid') || '';
    this.userService.updateuserProfile(this.userId,this.setUser).subscribe((data: any)=>
    {
      this.user=data;
      this.setUser = new User();
      this.gotoList();
    });
   }

   gotoList()
   {
    this.router.navigate(['userhome']);
   }




   closeAlert()
   {

   }
}
