import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserHomeComponent } from './user-home/user-home.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { ListSportUComponent } from './list-sport-u/list-sport-u.component';
import { ListofbatchesComponent } from './listofbatches/listofbatches.component';
import { BatchdetailsComponent } from './batchdetails/batchdetails.component';
import { GenerateReceiptComponent } from './generate-receipt/generate-receipt.component';
import { MyMembershipComponent } from './my-membership/my-membership.component';
import { CommonsModule } from '../commons/commons.module';
import { ThankYouComponent } from './thank-you/thank-you.component';
import { UpdateUserProfileComponent } from './update-user-profile/update-user-profile.component';
import { ApprovedMembershipComponent } from './approved-membership/approved-membership.component';
import { RenewMembershipComponent } from './renew-membership/renew-membership.component';



@NgModule({
  declarations: [UserHomeComponent, UpdateUserComponent, ListSportUComponent, ListofbatchesComponent, BatchdetailsComponent, GenerateReceiptComponent, MyMembershipComponent, ThankYouComponent, UpdateUserProfileComponent, ApprovedMembershipComponent, RenewMembershipComponent],
  imports: [
    CommonModule,
    CommonsModule
  ]
})
export class UserModule { }
