import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  private sportUrl = 'http://localhost:9090/user/availableSports';
  private batchUrl = 'http://localhost:9090/user/getBatches';
  private batchDetailUrl = 'http://localhost:9090/user/getBatchDetail';

  private batchcomments = 'http://localhost:9090/user/comments';

  private commentsToBatchByUser = 'http://localhost:9090/user/commentsToBatchByUser';

  private enrollment = 'http://localhost:9090/user/enroll';
  private invoiceurl = 'http://localhost:9090/user/getReceipt';
  private membershipUrl = 'http://localhost:9090/user/myMembership';

  private myaddComments = 'http://localhost:9090/user/myaddcomment';
  private url = "http://localhost:9090/user/username";


  private likesfobatch = "http://localhost:9090/user/likesByBatchId";


  private approvedmembership = "http://localhost:9090/user/approvedMembership";
  
  private renewmembership = "http://localhost:9090/user/renewMembership";


  //constructor(private http: HttpClient) { }

  constructor(private http: HttpClient) { }

  // get list of all sport
  getSportList(): any {
    return this.http.get(`${this.sportUrl}`);
  }


  // get all batches for particular sport

  getBatches(id: number): any{
    return this.http.get(`${this.batchUrl}/${id}`);
  }


  // batch info in detail
  getBatchDetails(id: number): any {
    return this.http.get(`${this.batchDetailUrl}/${id}`);
  }

  // getting comments on batch

  getBatchComments(id: number): any{
    return this.http.get(`${this.batchcomments}/${id}`);
  }

  // posting comment
  // http://localhost:9090/user/commentsToBatchByUser/1/2
  commentsByUser(comment:Object,bid :number,uid:number):any
  {
  
    
    return this.http.post(`http://localhost:9090/user/commentsToBatchByUser/${bid}/${uid}`,
      comment);

  }



  // batch enrollment function

  enrollToBatch(enroll:Object,userId:number, batchId:number):any
  {
    console.log("value of userId in user service: "+userId)
    console.log("value of batchId in user service: "+batchId)
    return this.http.post(`${this.enrollment}/${userId}/${batchId}`,enroll);
  }




  // generating receipt for user's enrolled batches
  getinvoice(userId: number, ): Observable<any> {
    return this.http.get(`${this.invoiceurl}/${userId}`);
  }


  // checking my memebership
  getMyMembership(userId:number):any
  {
  
    return this.http.get(`${this.membershipUrl}/${userId}`);
  }





  

// approved memberships

findByApprovedEnrollement(userId:number):any{
  return this.http.get(`${this.approvedmembership}/${userId}`);
}


// renewing membership
renewMembership(userId:number,batchId:number):Observable<any>{
  return this.http.get(`${this.renewmembership}/${userId}/${batchId}`, {responseType: 'text'});
}




// getting all likes for each batch

getAllLikes(batchId:number):any{
  return this.http.get(`${this.likesfobatch}/${batchId}`);
}

  postLike(batchId: number) {
    let userId = sessionStorage.getItem('userid');
    console.log(userId)
    let object = { id: 10 };

    console.log('http://localhost:9090/user/likesByBatchIdAndUserId/' + batchId + '/' + userId);
    // this.http.post('http://localhost:9090/user/likesByBatchIdAndUserId/' + batchId + '/' + userId, "hello")

    const req = this.http.post('http://localhost:9090/user/likesByBatchIdAndUserId/' + batchId + '/' + userId,
      JSON.stringify(object),
      {
        headers: new HttpHeaders()
          .set('Content-Type', 'application/json')
      }).subscribe((msg) => {
        console.log(msg)
      });


  }

  deleteLike(batchId: number) {
    let userId = sessionStorage.getItem('userid')||'';
    return this.http.delete(`http://localhost:9090/user/likesByBatchIdAndUserId/${batchId}/${userId}`);
  }


  getLike(batchId: number) {
    let userId = sessionStorage.getItem('userid');
    return this.http.get('http://localhost:9090/user/likesByBatchIdAndUserId/' + batchId + '/' + userId)
  }

  private getUserProfile = "http://localhost:9090/user/getprofile";

  getuserProfile(userId: number):any {
    
    return this.http.get(`${this.getUserProfile}/${userId}`)
  }


  private updateUserProfile = "http://localhost:9090/user/updateprofile";

  updateuserProfile(userId: number,user:Object):any {
    
    return this.http.get(`${this.updateUserProfile}/${userId}`)
  }


}
