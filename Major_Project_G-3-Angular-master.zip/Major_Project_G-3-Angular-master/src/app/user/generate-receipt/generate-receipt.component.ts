import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import { Invoice } from 'src/app/models/invoice';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-generate-receipt',
  templateUrl: './generate-receipt.component.html',
  styleUrls: ['./generate-receipt.component.css']
})
export class GenerateReceiptComponent implements OnInit {

  userId:any
  invoice: any

  constructor(private route: ActivatedRoute,private router: Router,
    private userService: UserServiceService) { }

  ngOnInit() {

    this.invoice = new Invoice()
    //this.userId = this.route.snapshot.params['userid'];
     this.userId = sessionStorage.getItem('userid') || '';

    console.log("user id in generate invoice"+this.userId)

    //  this.userService.getinvoice(this.userId)
    //   .subscribe(data => {
    //     console.log(data)
    //     this.invoice = data;
    //   }, error => console.log(error));

      this.userService.getinvoice(this.userId).subscribe((data: any)=>{
        this.invoice=data.content[0];
       
      })
  }


  goto()
  {
    this.router.navigate(['myMembership',this.userId])
  }
 
  }


  

