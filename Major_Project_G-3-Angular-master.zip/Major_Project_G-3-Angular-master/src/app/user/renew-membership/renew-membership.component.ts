import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Invoice } from 'src/app/models/invoice';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-renew-membership',
  templateUrl: './renew-membership.component.html',
  styleUrls: ['./renew-membership.component.css']
})
export class RenewMembershipComponent implements OnInit {

  
  membership: any;
  userId : any;
  batchId:number;
  constructor(private userService: UserServiceService,
    private router: Router,private route: ActivatedRoute) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData()
  {
    console.log(" before calling any method : "+this.membership)
    this.batchId = this.route.snapshot.params['id'];
    
     this.userId =sessionStorage.getItem("userid") || '';

    this.userService.renewMembership(this.userId,this.batchId).subscribe((data: Observable<Invoice[]>)=>
    {
      this.membership=data;
      console.log(this.membership)
    })
  }


  checkvalue()
  {
    if(this.membership?.includes("You have"))
    {
      
      return true;
    }
    return false;
  }

    checkval()
  {
    if(this.membership?.includes("You can"))
    {
     
      return true;
      
    }
    return false;
  }



  gotosports()
  {
    this.router.navigate(['listsportu']);
  }


  gotohome()
  {
    this.router.navigate(['userhome'])
  }
}
