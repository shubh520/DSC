import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Sport } from 'src/app/models/sport';

@Component({
  selector: 'app-list-sport-u',
  templateUrl: './list-sport-u.component.html',
  styleUrls: ['./list-sport-u.component.css']
})
export class ListSportUComponent implements OnInit {
  // sports: Observable<Sport[]>;
  sports:any;

  constructor(private userService: UserServiceService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    // this.sports = this.userService.getSportList();
    this.userService.getSportList().subscribe((data: any)=>{
      this.sports=data;
    })
  }

  getBatches(id: number){
    console.log(id)
    this.router.navigate(['listofbatches', id]);
  }
  
}
