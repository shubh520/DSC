import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListSportUComponent } from './list-sport-u.component';

describe('ListSportUComponent', () => {
  let component: ListSportUComponent;
  let fixture: ComponentFixture<ListSportUComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListSportUComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListSportUComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
