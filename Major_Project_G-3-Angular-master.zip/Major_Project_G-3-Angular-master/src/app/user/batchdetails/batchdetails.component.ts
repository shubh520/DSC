import { Component, OnInit } from '@angular/core';
import { Batch } from 'src/app/models/batch';
import { ActivatedRoute, Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import { Observable } from 'rxjs';
import { Comments } from 'src/app/models/comments';
import { Enrollment } from 'src/app/models/enrollment';
import { Likes } from 'src/app/models/likes';

@Component({
  selector: 'app-batchdetails',
  templateUrl: './batchdetails.component.html',
  styleUrls: ['./batchdetails.component.css'],
})
export class BatchdetailsComponent implements OnInit {
  id: number;
  commentDescription: string;
  userId: any;
  // batch: Batch;
  // com: Comments;
  batch: any[];
  com: any[];
  allLikes: Likes;
  commentsText: Comments;

  enroll: Enrollment;
  likecount: any;
  isFav: boolean;


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserServiceService
  ) { }


  ngOnInit() {
    this.commentsText = new Comments();
    this.enroll = new Enrollment();

    this.reloadData();


    this.userService.getLike(this.id).subscribe((data: any) => {
      console.log("likes dataa ->", data);
      this.isFav = data as boolean;

    })
  }

  reloadData() {
    this.id = this.route.snapshot.params['id'];
    // getting batch details
    // this.batch = this.userService.getBatchDetails(this.id)
    this.userService.getBatchDetails(this.id).subscribe((data: any[]) => {
      this.batch = data;
    });
    //getting comments
    // this.com = this.userService.getBatchComments(this.id)
    this.userService.getBatchComments(this.id).subscribe((data: any[]) => {
      this.com = data;
    });

    // getting all likes
    //this.allLikes = this.userService.getAllLikes(this.id);
    this.userService.getAllLikes(this.id).subscribe((data: Likes)=>
    {
    
      this.likecount = data;
    })
    console.log(this.allLikes);
  }


  //posting comment

  postComment() {
    this.userId = sessionStorage.getItem('userid') || '';
    // this.router.navigate(['batchdetails', this.id]);

    console.log('00000');
    this.userService
      .commentsByUser(this.commentsText, this.id, this.userId)
      .subscribe(() => {
        console.log('111111');

        console.log('22222');
      });
    this.userService.getBatchComments(this.id).subscribe((data: any[]) => {
      this.com = data;
    });
  
    console.log('33333');
    // this.router.navigate(['batchdetails',this.id]);
    window.location.reload();
    console.log('44444');
  }

  enrollToBatch() {
    this.userId = sessionStorage.getItem('userid') || '';

    this.userService.enrollToBatch(this.enroll, this.userId, this.id).subscribe(
      (data: any) => {},
      
         
    );

    this.router.navigate(['thankyou',this.id]);
  }


  toggleFav() {
    this.isFav = !this.isFav;
    if (this.isFav) {

      this.userService.postLike(this.id);
     
      this.likecount++;



      // window.location.reload();

    }
    else {
      this.userService.deleteLike(this.id).subscribe((msg: any) => {
       

      });
      this.likecount--;
      // window.location.reload();

    }
  }

}
