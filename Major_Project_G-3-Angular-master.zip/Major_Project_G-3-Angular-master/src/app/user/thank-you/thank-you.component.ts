import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-thank-you',
  templateUrl: './thank-you.component.html',
  styleUrls: ['./thank-you.component.css']
})
export class ThankYouComponent implements OnInit {


userId:any;
batchId:any;
userName:any;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private userService: UserServiceService) { }

  ngOnInit() {
    //this.batchId = this.route.snapshot.params['id'];
    this.reloadData();
  }


  reloadData() {

    this.userId = sessionStorage.getItem('userid') || '';
    this.userName = sessionStorage.getItem("username");
  }

  goto()
  {
    this.router.navigate(["invoice",this.userId])
  }
}
