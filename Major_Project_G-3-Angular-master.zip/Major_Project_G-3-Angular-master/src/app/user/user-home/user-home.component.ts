import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {

  constructor(private userService: UserServiceService,
    private router: Router) { }
    userId:any
    username: String;

  ngOnInit(): void {
   this.userId =sessionStorage.getItem("userid") || '';
   console.log(this.userId)
  }



  

 
 
}
