import { Component, OnInit } from '@angular/core';
import { Invoice } from 'src/app/models/invoice';
import { Observable } from 'rxjs';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-membership',
  templateUrl: './my-membership.component.html',
  styleUrls: ['./my-membership.component.css']
})
export class MyMembershipComponent implements OnInit {

  membership: Observable<Invoice[]>;
  userId : any;
  constructor(private userService: UserServiceService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.userId =sessionStorage.getItem("userid") || '';
    this.membership = this.userService.getMyMembership(this.userId);
  }

  approvedMembership()
  {
    this.userId =sessionStorage.getItem("userid") || '';
    this.router.navigate(['approvedMembership'])
  }
  



}
