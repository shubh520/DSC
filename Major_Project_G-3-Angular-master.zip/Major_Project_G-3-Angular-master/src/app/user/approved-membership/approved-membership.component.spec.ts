import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovedMembershipComponent } from './approved-membership.component';

describe('ApprovedMembershipComponent', () => {
  let component: ApprovedMembershipComponent;
  let fixture: ComponentFixture<ApprovedMembershipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprovedMembershipComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovedMembershipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
