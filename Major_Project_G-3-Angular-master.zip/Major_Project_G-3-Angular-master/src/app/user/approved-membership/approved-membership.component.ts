import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import { Invoice } from 'src/app/models/invoice';
import { Batch } from 'src/app/models/batch';

@Component({
  selector: 'app-approved-membership',
  templateUrl: './approved-membership.component.html',
  styleUrls: ['./approved-membership.component.css']
})
export class ApprovedMembershipComponent implements OnInit {

  invoice : Invoice[];
batchId:number;
  userId:any;
  constructor(private userService: UserServiceService,
    private router: Router,private route: ActivatedRoute) { }

  ngOnInit(){
    // this.userId = this.route.snapshot.params['userId'];
    this.reloadData();
  }

  reloadData()
  {
    this.userId =sessionStorage.getItem("userid") || '';
    this.userService.findByApprovedEnrollement(this.userId).subscribe((data: Invoice[])=>
    {
      this.invoice=data;
    })
  }
  renewMembership(batchId:number)
  {
    this.userId =sessionStorage.getItem("userid") || '';
    this.router.navigate(['renewMembership',batchId])
  }

 

}
