import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { CreateSportComponent } from './admin/create-sport/create-sport.component';
import { ListSportComponent } from './admin/list-sport/list-sport.component';
import { CreateManagerComponent } from './admin/create-manager/create-manager.component';
import { ListManagerComponent } from './admin/list-manager/list-manager.component';
import { UpdateManagerComponent } from './admin/update-manager/update-manager.component';
import { UpdateSportComponent } from './admin/update-sport/update-sport.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import { HomepageComponent } from './homepage/homepage.component';
import { AdminSportReportComponent } from './reports/admin-sport-report/admin-sport-report.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GlobalErrorHandler } from './shared/global-error-handler.interceptor';
import { HttpErrorInterceptorInterceptor } from './shared/http-error-interceptor.interceptor';
import { UnlockUserComponent } from './admin/unlock-user/unlock-user.component';

import { PendingEnrollmentComponent } from './manager/pending-enrollment/pending-enrollment.component';
import { RejectedEnrollmentComponent } from './manager/rejected-enrollment/rejected-enrollment.component';
import { ApprovedEnrollmentComponent } from './manager/approved-enrollment/approved-enrollment.component';

import { ListSportUComponent } from './user/list-sport-u/list-sport-u.component';
import { ListofbatchesComponent } from './user/listofbatches/listofbatches.component';
import { BatchdetailsComponent } from './user/batchdetails/batchdetails.component';
import { GenerateReceiptComponent } from './user/generate-receipt/generate-receipt.component';
import { UserHomeComponent } from './user/user-home/user-home.component';
import { MyMembershipComponent } from './user/my-membership/my-membership.component';
import { CommonsModule } from './commons/commons.module';
import { AuthinterceptorService } from './shared/auth-interceptor.service';
import { ThankYouComponent } from './user/thank-you/thank-you.component';
import { UpdateUserProfileComponent } from './user/update-user-profile/update-user-profile.component';
import { ApprovedMembershipComponent } from './user/approved-membership/approved-membership.component';
import { RenewMembershipComponent } from './user/renew-membership/renew-membership.component';
import { ListBatchComponent } from './manager/list-batch/list-batch.component';
import { UpdateBatchComponent } from './manager/update-batch/update-batch.component';
import { CreateBatchComponent } from './manager/create-batch/create-batch.component';


@NgModule({
  declarations: [
    AppComponent,
    UserHomeComponent,
    CreateSportComponent,
    ListSportComponent,
    CreateManagerComponent,
    ListManagerComponent,
    UpdateManagerComponent,
    UpdateSportComponent,
    HomepageComponent,
    AdminSportReportComponent,  
    UnlockUserComponent ,

    PendingEnrollmentComponent,
    ApprovedEnrollmentComponent,
    RejectedEnrollmentComponent,


    ListSportUComponent,
    ListofbatchesComponent,
    BatchdetailsComponent,
    GenerateReceiptComponent,
    MyMembershipComponent,
    ThankYouComponent,
    UpdateUserProfileComponent,
    ApprovedMembershipComponent,
    RenewMembershipComponent,
    ListBatchComponent,
    UpdateBatchComponent,
    CreateBatchComponent,

  ],

  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    ReactiveFormsModule,
    CommonsModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthinterceptorService,
      multi: true
    },

    {
      provide: ErrorHandler,
      useClass: GlobalErrorHandler
    },
    
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptorInterceptor,
      multi: true
    }

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
