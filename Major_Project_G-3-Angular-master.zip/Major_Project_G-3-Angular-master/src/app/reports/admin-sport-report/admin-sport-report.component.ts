import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AdminServiceService } from 'src/app/admin/admin-service.service';
import { Sport } from 'src/app/models/sport';

@Component({
  selector: 'app-admin-sport-report',
  templateUrl: './admin-sport-report.component.html',
  styleUrls: ['./admin-sport-report.component.css']
})
export class AdminSportReportComponent implements OnInit {
  constructor(private adminService: AdminServiceService) { }

    ngOnInit(){

    }

    exportSportPdf(){
this.adminService. exportSportPdf().subscribe(x=>{
const blob=new Blob([x],{type:'application/pdf'});

if(window.navigator && window.navigator.msSaveOrOpenBlob){
  window.navigator.msSaveOrOpenBlob(blob);
  return;
}

const data =window.URL.createObjectURL(blob);
const link =document.createElement('a');
link.href=data;
link.download='sport.pdf';
link.dispatchEvent(new MouseEvent ('click',{bubbles:true,cancelable:true,view:window}));


setTimeout(function(){
  window.URL.revokeObjectURL(data);
  link.remove();
},100)
});
    }
   }


