package com.g3dsc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G3dscApplication {

	public static void main(String[] args) {
		SpringApplication.run(G3dscApplication.class, args);
	}

}
