package com.g3dsc.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.time.LocalTime;
import com.g3dsc.Entity.Batch;
import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.g3dsc.Entity.Batch;
import com.g3dsc.Entity.Sport;
	




@Repository
public interface BatchRepository extends JpaRepository<Batch, Integer>{
//	b.setBatchId(b.getBatchId());
//	
//	b.setBatchType(b.getBatchType());
//	b.setBatchPrice(b.getBatchPrice());
//	
//	b.setBatchStartTime(b.getBatchStartTime());
//	b.setBatchEndTime(b.getBatchEndTime());
//	
//	b.setBatchStartDate(b.getBatchStartDate());
//	b.setBatchEndDate(b.getBatchEndDate());


	
 //@Query("select b from Batch b where b.sportId=?1")	
	@Query(value="select * from batch where sport_sport_id=?",nativeQuery = true)
	Optional<Batch> findBySportId(int id);
	
	 @Transactional
	 @Modifying
	 @Query(value = "UPDATE batch b SET b.batchType=?, b.batchPrice=?,b.batchStartTime=?,b.batchEndTime=?,b.batchStartDate=?,b.batchEndDate=? where batchId=? ", nativeQuery = true)
	 public void updateSportById(int batchId, Batch batch);
}
