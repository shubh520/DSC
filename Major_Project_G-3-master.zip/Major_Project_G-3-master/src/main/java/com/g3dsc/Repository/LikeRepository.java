package com.g3dsc.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.g3dsc.Entity.Likes;

public interface LikeRepository extends JpaRepository<Likes, Integer> {

}
