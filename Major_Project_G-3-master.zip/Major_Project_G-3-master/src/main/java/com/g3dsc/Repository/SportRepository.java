package com.g3dsc.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.g3dsc.Entity.Sport;

@Repository
public interface SportRepository extends JpaRepository<Sport, Integer>{
	Sport findBySportName(String sportName);
 
 @Transactional
 @Modifying
 @Query(value = "UPDATE sport s SET s.sportName=? where sportId=? ", nativeQuery = true)
 public void updateSportById(int sportId, Sport sport)
	 ;


}
