package com.g3dsc.Enum;

public enum AccountStatus {

	locked,
	unlocked,
	pending
}
