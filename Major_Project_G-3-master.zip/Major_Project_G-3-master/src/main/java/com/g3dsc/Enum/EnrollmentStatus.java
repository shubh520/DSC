package com.g3dsc.Enum;

public enum EnrollmentStatus {
	pending,
	approved,
	rejected
}
