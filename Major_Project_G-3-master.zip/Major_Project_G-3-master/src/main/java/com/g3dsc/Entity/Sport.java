package com.g3dsc.Entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Sport {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int sportId;
	private String sportName;
	
	@JsonBackReference
	@ManyToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL,mappedBy="sport")
	private List<User> user;
	
	@OneToMany(mappedBy = "sport")
	private List<Batch> batch;

	public Sport() {
		super();
		
	}

	public Sport(int sportId, String sportName, List<User> user) {
		super();
		this.sportId = sportId;
		this.sportName = sportName;
		this.user = user;
	}

	

	public Sport(int sportId, String sportName) {
		super();
		this.sportId = sportId;
		this.sportName = sportName;
	}

	public int getSportId() {
		return sportId;
	}

	public void setSportId(int sportId) {
		this.sportId = sportId;
	}

	public String getSportName() {
		return sportName;
	}

	public void setSportName(String sportName) {
		this.sportName = sportName;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Sport [sportId=" + sportId + ", sportName=" + sportName + ", user=" + user + "]";
	}
	
	

}
