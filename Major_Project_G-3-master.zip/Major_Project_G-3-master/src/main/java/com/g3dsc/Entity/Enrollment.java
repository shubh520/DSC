
package com.g3dsc.Entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Enrollment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int enrollmentId;
	private String enrollmentStatus;
	private LocalDate enrollmentDate;
		
	@ManyToOne
	private User user;
	
	@ManyToOne
	private Batch batch;

	public Enrollment() {
		super();
	}

	//ctor with all parameters
	public Enrollment(int enrollmentId, String enrollmentStatus, LocalDate enrollmentDate, User user, Batch batch) {
		super();
		this.enrollmentId = enrollmentId;
		this.enrollmentStatus = enrollmentStatus;
		this.enrollmentDate = enrollmentDate;
		this.user = user;
		this.batch = batch;
	}

	//ctor without id
	public Enrollment(String enrollmentStatus, LocalDate enrollmentDate, User user, Batch batch) {
		super();
		this.enrollmentStatus = enrollmentStatus;
		this.enrollmentDate = enrollmentDate;
		this.user = user;
		this.batch = batch;
	}


	public Enrollment(String enrollmentStatus, LocalDate enrollmentDate) {
		super();
		this.enrollmentStatus = enrollmentStatus;
		this.enrollmentDate = enrollmentDate;
	}
	
	

	public int getEnrollmentId() {
		return enrollmentId;
	}

	public void setEnrollmentId(int enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public String getEnrollmentStatus() {
		return enrollmentStatus;
	}

	public void setEnrollmentStatus(String enrollmentStatus) {
		this.enrollmentStatus = enrollmentStatus;
	}

	public LocalDate getEnrollmentDate() {
		return enrollmentDate;
	}

	public void setEnrollmentDate(LocalDate enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Batch getBatch() {
		return batch;
	}

	public void setBatch(Batch batch) {
		this.batch = batch;
	}

	@Override
	public String toString() {
		return "Enrollment [enrollmentId=" + enrollmentId + ", enrollmentStatus=" + enrollmentStatus
				+ ", enrollmentDate=" + enrollmentDate + ", user=" + user + ", batch=" + batch + "]";
	}
	
	
	
}
