package com.g3dsc.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Offer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int offerId;

	private String offerPrice;

	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "batchId")
	private Batch batch;
	//private String batchId;

	public Offer() {
		super();
	}
	public Offer(int offerId, String offerPrice, Batch batch) {
		super();
		this.offerId = offerId;
		this.offerPrice = offerPrice;
		this.batch = batch;
	}
	public Offer(String offerPrice) {
		super();
		this.offerPrice = offerPrice;
	}
	
	
	
	public int getOfferId() {
		return offerId;
	}
	public void setOfferId(int offerId) {
		this.offerId = offerId;
	}
	public String getOfferPrice() {
		return offerPrice;
	}
	public void setOfferPrice(String offerPrice) {
		this.offerPrice = offerPrice;
	}
	public Batch getBatch() {
		return batch;
	}
	public void setBatch(Batch batch) {
		this.batch = batch;
	}
	@Override
	public String toString() {
		return "Offer [offerId=" + offerId + ", offerPrice=" + offerPrice + ", batch=" + batch + "]";
	}
	
	
	
}
