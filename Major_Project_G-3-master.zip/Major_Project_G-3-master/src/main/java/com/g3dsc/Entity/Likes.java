package com.g3dsc.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Likes {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int likeId;
	private int likeCount;

	@JsonBackReference
	@ManyToOne
	private User user;
	
	@JsonBackReference
	@ManyToOne
	private Batch batch;

	public Likes() {
		super();
	}

	public Likes(int likeId, int likeCount, User user, Batch batch) {
		super();
		this.likeId = likeId;
		this.likeCount = likeCount;
		this.user = user;
		this.batch = batch;
	}

	public Likes(int likeCount) {
		super();
		this.likeCount = likeCount;
	}

	
	
	public int getLikeId() {
		return likeId;
	}

	public void setLikeId(int likeId) {
		this.likeId = likeId;
	}

	public int getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Batch getBatch() {
		return batch;
	}

	public void setBatch(Batch batch) {
		this.batch = batch;
	}

	@Override
	public String toString() {
		return "Likes [likeId=" + likeId + ", likeCount=" + likeCount + ", user=" + user + ", batch=" + batch + "]";
	}
	
	
	
}
