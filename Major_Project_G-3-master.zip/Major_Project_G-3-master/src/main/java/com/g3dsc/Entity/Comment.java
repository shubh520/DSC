package com.g3dsc.Entity;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Comment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int commentId;
	private String commentDescription;
	
	@ManyToOne
	private User user;
	
	@ManyToOne
	private Batch batch;
	//private int userId;
	//private int batchId;

	// ctor without parameters
	public Comment() {
		super();
	}
	
	//ctor with all parameters
	public Comment(int commentId, String commentDescription, User user, Batch batch) {
		super();
		this.commentId = commentId;
		this.commentDescription = commentDescription;
		this.user = user;
		this.batch = batch;
	}

	//ctor to add comment description
	public Comment(String commentDescription) {
		super();
		this.commentDescription = commentDescription;
	}
	
	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public String getCommentDescription() {
		return commentDescription;
	}

	public void setCommentDescription(String commentDescription) {
		this.commentDescription = commentDescription;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Batch getBatch() {
		return batch;
	}

	public void setBatch(Batch batch) {
		this.batch = batch;
	}

	@Override
	public String toString() {
		return "Comment [commentId=" + commentId + ", commentDescription=" + commentDescription + ", user=" + user
				+ ", batch=" + batch + "]";
	}
	
	
	
}
