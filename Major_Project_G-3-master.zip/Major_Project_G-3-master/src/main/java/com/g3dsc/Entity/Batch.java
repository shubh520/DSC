package com.g3dsc.Entity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Batch {
	@Id
	private int batchId;
	private String batchType;
	private String batchPrice;
	private LocalTime batchStartTime;
	private LocalTime batchEndTime;
	private LocalDate batchStartDate ;
	private LocalDate batchEndDate ;
	
	@OneToMany(mappedBy = "batch")
	private List<Comment> comment;
	
	@OneToMany(mappedBy = "batch")
	private List<Likes> likes;
	
	@ManyToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL, mappedBy="batch")
	private List<User> user;
	
	@ManyToOne
	private Sport sport;
	
	@OneToMany
	private List<Enrollment> enrollment;

	// constructor without parameters
	public Batch() {
		super();
	}

	//parameterised ctor with all fields
	public Batch(int batchId, String batchType, String batchPrice, LocalTime batchStartTime, LocalTime batchEndTime,
			LocalDate batchStartDate, LocalDate batchEndDate, List<Comment> comment, List<Likes> likes, List<User> user,
			Sport sport, List<Enrollment> enrollment) {
		super();
		this.batchId = batchId;
		this.batchType = batchType;
		this.batchPrice = batchPrice;
		this.batchStartTime = batchStartTime;
		this.batchEndTime = batchEndTime;
		this.batchStartDate = batchStartDate;
		this.batchEndDate = batchEndDate;
		this.comment = comment;
		this.likes = likes;
		this.user = user;
		this.sport = sport;
		this.enrollment = enrollment;
	}

	//ctor to add batch
	public Batch(String batchType, String batchPrice, LocalTime batchStartTime, LocalTime batchEndTime,
			LocalDate batchStartDate, LocalDate batchEndDate) {
		super();
		this.batchType = batchType;
		this.batchPrice = batchPrice;
		this.batchStartTime = batchStartTime;
		this.batchEndTime = batchEndTime;
		this.batchStartDate = batchStartDate;
		this.batchEndDate = batchEndDate;
	}
	
	public int getBatchId() {
		return batchId;
	}

	public void setBatchId(int batchId) {
		this.batchId = batchId;
	}

	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}

	public String getBatchPrice() {
		return batchPrice;
	}

	public void setBatchPrice(String batchPrice) {
		this.batchPrice = batchPrice;
	}

	public LocalTime getBatchStartTime() {
		return batchStartTime;
	}

	public void setBatchStartTime(LocalTime batchStartTime) {
		this.batchStartTime = batchStartTime;
	}

	public LocalTime getBatchEndTime() {
		return batchEndTime;
	}

	public void setBatchEndTime(LocalTime batchEndTime) {
		this.batchEndTime = batchEndTime;
	}

	public LocalDate getBatchStartDate() {
		return batchStartDate;
	}

	public void setBatchStartDate(LocalDate batchStartDate) {
		this.batchStartDate = batchStartDate;
	}

	public LocalDate getBatchEndDate() {
		return batchEndDate;
	}

	public void setBatchEndDate(LocalDate batchEndDate) {
		this.batchEndDate = batchEndDate;
	}

	public List<Comment> getComment() {
		return comment;
	}

	public void setComment(List<Comment> comment) {
		this.comment = comment;
	}

	public List<Likes> getLikes() {
		return likes;
	}

	public void setLikes(List<Likes> likes) {
		this.likes = likes;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}

	public Sport getSport() {
		return sport;
	}

	public void setSport(Sport sport) {
		this.sport = sport;
	}

	public List<Enrollment> getEnrollment() {
		return enrollment;
	}

	public void setEnrollment(List<Enrollment> enrollment) {
		this.enrollment = enrollment;
	}

	@Override
	public String toString() {
		return "Batch [batchId=" + batchId + ", batchType=" + batchType + ", batchPrice=" + batchPrice
				+ ", batchStartTime=" + batchStartTime + ", batchEndTime=" + batchEndTime + ", batchStartDate="
				+ batchStartDate + ", batchEndDate=" + batchEndDate + ", comment=" + comment + ", likes=" + likes
				+ ", user=" + user + ", sport=" + sport + ", enrollment=" + enrollment + "]";
	}

	

}
