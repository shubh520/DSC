package com.g3dsc.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.g3dsc.Entity.Sport;
import com.g3dsc.Entity.User;
import com.g3dsc.Service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {

	

	
	
	@Autowired
	public AdminService adminService;
	
	
	
	// getting all managers
	@GetMapping("/manager")
	private List<User> getManager(){
		return	adminService.getManager();
	}
	
	
	// get manager by id
	@GetMapping("/manager/{id}")
	public Optional<User> getManagerById(@PathVariable int id) {
	return adminService.getManagerById(id);
	}
	
	
	// adding new manager
	@PostMapping("/manager")
	private User addManager(@RequestBody User manager){
		return adminService.addManager(manager);
	}
	
	// updating manager by id
	@PutMapping("/manager/{id}")
	private User updateManager(@PathVariable int id, @RequestBody User manager) {
		adminService.updateManager(id, manager);
		return manager;
	}
	
	
	// deleting manager by id
	@DeleteMapping("/manager/{id}")
	private String deleteManager(@PathVariable int id) {
		adminService.deleteManager(id);
		return "User deleted";
	}
	
	// getting all Sports
	@GetMapping(value="/sport", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Sport> getAllSports(){
		return adminService.getAllSports();
	}
	
	
	// adding new sport
	@PostMapping(value="/sport")
	public String  addSport(@RequestBody Sport sport) {
		Sport sports = new Sport(sport.getSportId(),sport.getSportName());
		adminService.addSport(sports);
		return "Successfully added sport " +sport.getSportName();
	}
	
	
	//  deleting sport by id
	@DeleteMapping("/sport/{sportId}")
	public String deleteSportById(@PathVariable int sportId){
		adminService.deleteSport(sportId);
		return "Successfully deleted sport: " +sportId;
	}
	
	
	//updating sport by id
	  @PutMapping("/sport/{sportId}") 
	private String updateSportId(@PathVariable int sportId, @RequestBody Sport sport) {
		  adminService.updateSportById(sportId, sport);
			return "Successfully updated sport: " +sport;
	

	  }
}
	

