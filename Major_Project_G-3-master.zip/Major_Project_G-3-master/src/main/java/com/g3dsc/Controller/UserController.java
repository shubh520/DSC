package com.g3dsc.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.g3dsc.Entity.Batch;
import com.g3dsc.Entity.Likes;
import com.g3dsc.Entity.Sport;
import com.g3dsc.Entity.User;
import com.g3dsc.Service.UserService;

@RestController
@RequestMapping("/user")
public class UserController
{
	
	@Autowired
	public UserService userservice;
	
	
	
	//get all sports
	@GetMapping("/getAllSports")
	public List<Sport> getAllSports()
	{
		return userservice.getAllSports();
	}
	
	//get batch for particular project
	@GetMapping("/getBatches/{id}")
	public Optional<Batch> getBatches(@PathVariable int id)
	{
		return userservice.getBatches(id);
	}
	
	// get batches in detail
	@GetMapping("/getBatchDetail/{id}")
	public Optional<Batch> getBatchDetail(@PathVariable int id)
	{
		return userservice.getBatchDetail(id);
	}
	
	
	//get likes
	
	@GetMapping("/getLikes")
	public List<Likes> getLikes()
	{
		return userservice.getLikes();
	}
}
