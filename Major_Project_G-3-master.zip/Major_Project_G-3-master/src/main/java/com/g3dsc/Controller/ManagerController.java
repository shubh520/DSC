package com.g3dsc.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.g3dsc.Entity.Batch;
import com.g3dsc.Entity.Offer;
import com.g3dsc.Entity.Sport;
import com.g3dsc.Entity.User;
import com.g3dsc.Service.AdminService;
import com.g3dsc.Service.ManagerService;

@RestController
@RequestMapping("/manager")
public class ManagerController {
	@Autowired
	public ManagerService managerService;
	
	
	
	// Fetching all Batches
	@GetMapping("/batch")
	private List<Batch> getBatches(){
		return	managerService.getBatches();
	}

	// adding new batch
	@PostMapping("/batch")
	private Batch addBatch(@RequestBody Batch batch){
		return managerService.addBatch(batch);
	}

	// deleting batch by id
	@DeleteMapping("/batch/{id}")
	private String deleteBatch(@PathVariable int id) {
		managerService.deleteBatch(id);
		return "Batch deleted";
	}
	
//	// updating batch by id
//	@PutMapping("/batch/{id}")
//	private Batch updateBatch(@PathVariable int id, @RequestBody Batch batch) {
//		managerService.updateBatch(id, batch);
//		return batch +"updated";
//	}
	//updating batch by id
	  @PutMapping("/batch/{batchId}") 
	private String updateBatchById(@PathVariable int batchId, @RequestBody Batch batch) {
		  managerService.updateBatchById(batchId, batch);
			return "Batch Updated ";
	

	  }
	  
	  /*Batch Ends*/

	  /*Offer Begins*/
	// Fetching all offers
		@GetMapping("/offer")
		private List<Offer> getOffer(){
			return	managerService.getOffer();
		}
		
		// adding new offer
		@PostMapping("/offer")
		private Offer addOffer(@RequestBody Offer offer){
			return managerService.addOffer(offer);
		}
		
		// deleting offer by id
		@DeleteMapping("/offer/{id}")
		private String deleteOffer(@PathVariable int id) {
			managerService.deleteOffer(id);
			return "Offer deleted";
		}

	  /*Offer Ends*/

}
