package com.g3dsc.Dto;

public class BatchDto {

}
