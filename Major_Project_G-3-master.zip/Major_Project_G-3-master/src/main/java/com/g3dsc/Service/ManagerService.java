package com.g3dsc.Service;

import java.util.List;

import com.g3dsc.Entity.Batch;
import com.g3dsc.Entity.Offer;

public interface ManagerService {

	public List<Batch> getBatches();

	public Batch addBatch(Batch batch);

	public void deleteBatch(int id);

	//public void updateBatch(int id, Batch batch);

	public void updateBatchById(int batchId, Batch batch);
/*Batch Ends*/
	
	/*Offer Begins*/
	/*Offer Ends*/
	public List<Offer> getOffer();
	

	public Offer addOffer(Offer offer);

	public void deleteOffer(int id);
	

}
