package com.g3dsc.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.g3dsc.Entity.Sport;
import com.g3dsc.Entity.User;
import com.g3dsc.Repository.SportRepository;
import com.g3dsc.Repository.UserRepository;


@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	SportRepository sportrepository;

	@Override
	public List<User> getManager() {
		System.out.println("in getting user");
		return userRepository.findAll();
	}

	@Override
	public Optional<User> getManagerById(int id) {
		return userRepository.findById(id);
	}

	@Override
	public User addManager(User manager) {
		return userRepository.save(manager);
	}

	@Override
	public void updateManager(int id, User manager) {
		
		List<User> managerList = userRepository.findAll();
		
		 managerList = managerList.stream().map(u->{
			if(u.getUserId() == id) {
				u.setUserId(u.getUserId());
				u.setFirstName(manager.getFirstName());
				u.setLastName(manager.getLastName());
				u.setUserCity(manager.getUserCity());
				u.setUserEmail(manager.getUserEmail());
				u.setRole(manager.getRole());
				u.setUserPassword(manager.getUserPassword());
				u.setUserName(manager.getUserName());
			}
			userRepository.save(u);
			return u;
		}).collect(Collectors.toList());
		
	
		
		
	}

	@Override
	public void deleteManager(int id) {
		userRepository.deleteById(id);	
	}
	
	
	
	@Override
	public void addSport(Sport sport) {
		sportrepository.save(sport);
		
	}

	@Override
	public List<Sport> getAllSports() {
		return sportrepository.findAll();
	}

	@Override
	public Sport getSport(String sportName) {
		return sportrepository.findBySportName(sportName);
	}

	@Override
	public void deleteSport(int sportId) {
		sportrepository.deleteById(sportId);
		
		
	}
	  
	
	 @Override
	 public void updateSportById(int sportId, Sport sport) {
			
			List<Sport> sportList = sportrepository.findAll();
			
			 sportList = sportList.stream().map(s->{
				if(s.getSportId() == sportId) {
					s.setSportId(s.getSportId());
					s.setSportName(sport.getSportName());
					
				}
				sportrepository.save(s);
				return s;
			}).collect(Collectors.toList());

	 }
}
		

	

