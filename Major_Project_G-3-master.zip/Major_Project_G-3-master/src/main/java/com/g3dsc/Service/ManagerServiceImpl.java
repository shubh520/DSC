package com.g3dsc.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.g3dsc.Entity.Batch;
import com.g3dsc.Entity.Offer;
import com.g3dsc.Entity.User;
import com.g3dsc.Repository.BatchRepository;
import com.g3dsc.Repository.OfferRepository;


@Service
public class ManagerServiceImpl implements ManagerService {
	
	@Autowired
	BatchRepository batchRepository;
	
	@Autowired
	OfferRepository offerRepository;
	
	
	
	
	@Override
	public List<Batch> getBatches() {
		return  batchRepository.findAll();
	}

	@Override
	public Batch addBatch(Batch batch) {
		return batchRepository.save(batch);
	}

	@Override
	public void deleteBatch(int id) {
		batchRepository.deleteById(id);	
		
	}

//	@Override
//	public void updateBatch(int id, Batch batch) {
//		List<Batch> batchList = batchRepository.findAll();
//		
//		batchList = batchList.stream().map(b->{
//			if(b.getBatchId() == id) {
//				b.setBatchId(b.getBatchId());
//				
//				b.setBatchType(b.getBatchType());
//				b.setBatchPrice(b.getBatchPrice());
//				
//				b.setBatchStartTime(b.getBatchStartTime());
//				b.setBatchEndTime(b.getBatchEndTime());
//				
//				b.setBatchStartDate(b.getBatchStartDate());
//				b.setBatchEndDate(b.getBatchEndDate());
//				
//			}
//			batchRepository.save(b);
//			return b;
//		}).collect(Collectors.toList());
//		
//		
//	}

	@Override
	public void updateBatchById(int batchId, Batch batch) {
List<Batch> batchList = batchRepository.findAll();
		
		batchList = batchList.stream().map(b->{
			if(b.getBatchId() == batchId) {
				b.setBatchId(b.getBatchId());
				
				b.setBatchType(b.getBatchType());
				b.setBatchPrice(b.getBatchPrice());
				
				b.setBatchStartTime(b.getBatchStartTime());
				b.setBatchEndTime(b.getBatchEndTime());
				
				b.setBatchStartDate(b.getBatchStartDate());
				b.setBatchEndDate(b.getBatchEndDate());
				
			}
			batchRepository.save(b);
			return b;
		}).collect(Collectors.toList());
		
		
	}
	/*Batch Ends*/
	/*Offer Begins*/

	@Override
	public List<Offer> getOffer() {
		return  offerRepository.findAll();
	}

	@Override
	public Offer addOffer(Offer offer) {
		return offerRepository.save(offer);
	}

	@Override
	public void deleteOffer(int id) {
		offerRepository.deleteById(id);	
	}
	
	
	
	
	/*Offer Ends*/

}
