package com.g3dsc.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.g3dsc.Entity.Batch;
import com.g3dsc.Entity.Likes;
import com.g3dsc.Entity.Sport;
import com.g3dsc.Entity.User;
import com.g3dsc.Repository.BatchRepository;
import com.g3dsc.Repository.LikeRepository;
import com.g3dsc.Repository.SportRepository;
import com.g3dsc.Repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	BatchRepository batchrepo;
	
	@Autowired
	SportRepository sportrepo;
	
	@Autowired
	LikeRepository likerepo;
	public UserServiceImpl()
	{
		
	}

	//getting all sports
	@Override
	public List<Sport> getAllSports() {
		
		return sportrepo.findAll();
	}


	//getting batches for particular sport
	@Override
	public Optional<Batch> getBatches(int id) {
		
		return batchrepo.findBySportId(id);
	}
	
	// showing details about batches with offer
	@Override
	public Optional<Batch> getBatchDetail(int id) {
		
		return batchrepo.findById(id);
	}

	@Override
	public List<Likes> getLikes() {
		// TODO Auto-generated method stub
		return likerepo.findAll();
	}




	

	
	

}
