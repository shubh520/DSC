package com.g3dsc.Service;

import java.util.List;
import java.util.Optional;

import com.g3dsc.Entity.Sport;
import com.g3dsc.Entity.User;



public interface AdminService {
	
	public List<User> getManager();

	public Optional<User> getManagerById(int id);
	
	public User addManager(User manager);

	public void updateManager(int id, User manager);

	public void deleteManager(int id);
	
	public void addSport(Sport sport);
	public List<Sport> getAllSports();
	public Sport  getSport(String sportName);
	public void deleteSport(int sportId);
   public void  updateSportById(int sportId, Sport sport);
	 
	 
}
