package com.g3dsc.Service;

import java.util.List;
import java.util.Optional;

import com.g3dsc.Entity.Batch;
import com.g3dsc.Entity.Likes;
import com.g3dsc.Entity.Sport;
import com.g3dsc.Entity.User;

public interface UserService
{
	//getting all sports
	public List<Sport> getAllSports();
	

	//show batches for particular sport
	public Optional<Batch> getBatches(int id);
	
	// showing details about batches with offer
	public Optional<Batch> getBatchDetail(int id);
	
	//getting likes
		public List<Likes> getLikes();
		
	
}
