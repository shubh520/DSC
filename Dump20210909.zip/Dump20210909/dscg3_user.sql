-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: dscg3
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `account_nonlocked` tinyint(1) DEFAULT '1',
  `account_status` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `no_of_attempts` int(11) NOT NULL DEFAULT '0',
  `reset_token` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL,
  `user_city` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_j09k2v8lxofv2vecxu2hde9so` (`user_email`),
  UNIQUE KEY `UK_lqjrcobrh9jc8wpcar64q1bfh` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,0,'pending','Alex','Carry',0,NULL,'admin','New York','alexc@hotmail.com','admin1','$2a$10$S2DHyB14xd2HB4dMDdZIu.ZHCmsm4me4blRmMIA6plgLUrJ2eAr3.'),(2,0,'pending','Marcus','Stoinis',0,NULL,'manager','Paris','marcus@hotmail.com','marcus','$2a$10$zZlLJSjEmPoEadEAgxblOOFrkfGbwWPBIqNvbxenn0Kn1P6dIRhVK'),(3,0,'pending','Andrew','Flintoff',0,NULL,'manager','Dubai','andrew@hotmail.com','andrew','$2a$10$H71AMDyq3aHPqL50m9GyZeo2EuYDMQhg7zQnLmBt0739Z20NCBoIi'),(4,0,'pending','Chris','Gayle',0,NULL,'manager','Singapore','chris@hotmail.com','chris','$2a$10$1LISHYEue1mQXbY4W4UnOO/VTqkVyiaVzSAz69UxpsnpdEGtxY4h.'),(5,0,'pending','Adam','Grilchrist',0,NULL,'manager','Macau','adam@hotmail.com','adam','$2a$10$Jj1uOKK9ov8XdlQvwjVdkeAZRDywmlLElOHJnWzSokiExNRfosjaG'),(6,0,'pending','Shaun','Tate',0,NULL,'customer','Bangkok','shaun@hotmail.com','shaun','$2a$10$U7CLLvOkHAwh7OxAdF/n3u7l10NNsllF3IAfJFUGB2BWS0Cb/V.V2'),(7,0,'pending','Ajanta','Mendis',0,NULL,'customer','New York','ajanta@hotmail.com','ajanta','$2a$10$LbXZ06BD.cYgai5nrgOoOOm2bU3Xv4.QZO8BW/HSwHqTsUbmkkZle'),(8,0,'pending','Ricky','Ponting',0,NULL,'customer','Singapore','ricky@hotmail.com','ricky','$2a$10$ArDvf.R78ZerZc8ipGaGiuasbQOQi6I/uVsTqV4lf6nKcbRb6cDi.'),(9,0,'pending','Kevin ','Pietersen',0,NULL,'customer','Paris','kevin@hotmail.com','kevin','$2a$10$HywjYYwZpHgl6EFWrzVTTuhYNaX7k6rqbbcgYbJzblfMm656TLrDq'),(10,0,'pending','Kumar','Sangakara',0,NULL,'customer','Macau','kumar@hotmail.com','kumar','$2a$10$RVOe8.nvYCL/PoYw6uQB.usngxs8Y7LOikvx9lemQVa.JVCDMhy2O'),(11,0,'pending','Sara','Tendulkar',0,NULL,'customer','Mumbai','sachin@hotmail.com','sachin','$2a$10$09xFBt/uZfi3o8Lp95Ax9OwaqM6aw4UFurHA.CUbWk9jYO6gOCM3W'),(12,0,'pending','Virat','Kohli',0,NULL,'customer','New Delhi','virat@hotmail.com','virat','$2a$10$CE0DNwN0D.wrDie/rDq0vew63Tb24mpYBPW1FOv5qDW1YSpyq8Bii');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-09 12:48:38
